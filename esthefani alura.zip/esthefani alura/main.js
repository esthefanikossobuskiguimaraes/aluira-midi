alert ('Olá mundo');
